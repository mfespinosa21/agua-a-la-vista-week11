# Synthetic user and method
Mari,54, is an invented adult managing a shared tank in Mexico City. She uses WhatsApp, reads slowly and distrusts unfamiliar apps. This persona comes from the research-defined target user and hypothetical accessibility needs, not from an interview. A separate fresh-context model performed the review. Its initial text-only review was followed by actual ordered screenshots of the running application in a separate browser tab. This is simulated Layer1 testing, not evidence of real user success.

# Ordered screen walkthrough: returned reviewer log
## 1. Initial screen
Observed: simulation warning visible, large headline, controls below initial viewport.
Synthetic narration: Ya vi que es inventado... donde veo el nivel?
Confusion: task begins below the first screen. Suggested future refinement: shorter header. Not yet changed.
## 2. Manual reading
Observed: tank65%, input65 and age5. Updated labels: Lectura manual: tu escribes el nivel; Ejemplo inventado: no mide tu tinaco.
Synthetic narration: Ah, yo pongo el numero. Pero de donde lo saco?
Change made: explain only qualified-installation/local safe reference, never climb/open/look into tank. Real installation remains untested.
## 3. Digital25%
Observed: low warning plus safe-reference instructions.
Synthetic narration: Ya entendi que esta bajo; me lo dice dos veces y tengo bastante que leer.
Remaining issue: duplicated warning text; possible simplification not yet tested.
## 4. Digital28%
Initial observed bug: original interface showed ordinary availability and about0.5hours to25%, despite +/-5 points crossing threshold.
Synthetic narration: Con25 me avisa, pero pongo28 y ya dice normal. Ya puedo esperar media hora?
Fix: warn when lower uncertainty bound reaches25%; remove countdown in26-30% interval. Reviewer verified actual screen at28: uncertainty warning visible and no countdown.
Remaining confusion: fixed65-to70 example appeared under28. Reviewer recommended current interval. Final improvement: range now updates to23-33% at28. Mechanical threshold tests remain passing; dynamic range verified separately in browser.
## 5. No available action
Initial wording implied a response was logged. Synthetic narration: Dice que se registra... ya guardo mi problema?
Fix: En un piloto futuro se podria registrar con tu permiso. Esta demostracion no guarda tu seleccion.
Reviewer verified the corrected screen. No message is sent and no support appointment is offered. Lack of a feasible response remains a service constraint.
## 6. Costs
Observed: MXN per installation/first year; not quotes or a charge offer; digital0 marked as pending assumption. Results1000/1000/250/20%.
Synthetic narration: No me estan cobrando. Contribucion para quien? Retiro de que?
Remaining issue: technical cost terms need plainer explanation. No claim of actual prices or payment commitment.
## 7. Pilot and privacy
Observed: six-household comparison explicitly not performed; no personal data, landlord views, sales or remote shutoff.
Synthetic narration: Entonces todavia lo van a probar. Orden aleatorio y evidencia inconclusa no me dicen mucho.
Suggested future refinement: keep methodology in details for this user type. Not yet tested.

# What changed and what this proves
The worst issue was false reassurance around an uncertain low reading. It was fixed, mechanically tested at28/30/31 and visually rechecked. Wording that implied registration was also fixed. The review generated usability hypotheses; it cannot establish household acceptance, accessible field installation, sensor accuracy, business demand or prevented shortages. No interviews or real household pilot were completed. Screenshot observations were transient QA outputs, not archived user evidence.
