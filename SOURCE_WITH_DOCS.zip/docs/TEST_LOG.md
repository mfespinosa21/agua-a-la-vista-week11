# Mechanical evidence
Actual run on 25 October 2026 (Mexico City).
First pass: 16 domain checks passed. Browser flow checked manual default, low-level scenario, optional alerts, no-action response and cost defaults.
Observed bug: 28% +/- 5 points displayed ordinary availability, although its lower bound23% crosses the25% low threshold. Fixed with an uncertainty warning at26-30%; added tests at28,30,31.
Observed interaction risk: inputs could change while the old display remained until submission. Fixed by refreshing validation/output on each input event.
Clarified that selecting no action is not saved; removed external font requests.
Second pass: regression and browser checks recorded after correction. No field measurements, missed-warning rates or real household results claimed.
