const assert=require('node:assert/strict'),w=require('../dist/model.js');let n=0;function check(name,f){try{f();console.log('PASS '+name);n++}catch(e){console.log('FAIL '+name+': '+e.message);process.exitCode=1}}
check('0 is low',()=>assert.equal(w.reading(0,0).status,'low'));
check('100 valid',()=>assert.equal(w.reading(100,5).status,'normal'));
check('stale unknown',()=>assert.equal(w.reading(50,61).status,'unknown'));
check('60 min boundary',()=>assert.equal(w.reading(50,60).status,'normal'));
check('empty rejected',()=>assert.throws(()=>w.number('',0,100)));
check('negative rejected',()=>assert.throws(()=>w.number(-1,0,100)));
check('NaN rejected',()=>assert.throws(()=>w.number('abc',0,100)));
check('infinite rejected',()=>assert.throws(()=>w.number(Infinity,0,100)));
check('known fitted slope',()=>assert.equal(w.fit([0,1,2,3],[80,75,70,65]).slope,-5));
check('forecast 8 hours',()=>assert.equal(w.forecast([0,1,2,3],[80,75,70,65],65,5).hours,8));
check('rising no forecast',()=>assert.equal(w.forecast([0,1,2],[20,30,40],40,5),null));
check('flat no forecast',()=>assert.equal(w.forecast([0,1,2],[40,40,40],40,5),null));
check('stale no forecast',()=>assert.equal(w.forecast([0,1,2],[60,50,40],40,90),null));
check('cost total and margin',()=>assert.deepEqual(w.costs([400,300,200,100,0,0,1250]),{total:1000,contribution:250,margin:20}));
check('zero fee no division',()=>assert.equal(w.costs([0,0,0,0,0,0,0]).margin,null));
check('negative cost rejected',()=>assert.throws(()=>w.costs([-1,0,0,0,0,0,0])));
console.log(n+' checks passed');

check('uncertainty crosses threshold at28',()=>assert.equal(w.reading(28,5).status,'uncertain'));
check('30 boundary uncertain',()=>assert.equal(w.reading(30,5).status,'uncertain'));
check('31 above uncertainty',()=>assert.equal(w.reading(31,5).status,'normal'));
